# TA Automation Engine

A Google Apps Script that automates the end-to-end offer and onboarding workflow — from generating offer checklists and emails to employment agreements and onboarding data pushes — all from a custom menu inside your Google Sheet.

Built for HR and Talent Acquisition teams who manage offers in Google Sheets and store documents in Google Drive.

---

## What It Does

### FTE Offers
| Step | What Happens |
|------|-------------|
| 1. Generate Offer Checklist | Fills a Google Doc template with candidate data (CTC, level, hike %, ESOP, HRBP) and saves a PDF to Drive |
| 2. Generate Offer Email | Creates a personalized offer email PDF using level-specific templates (senior/junior, with/without joining bonus) |
| 3. Move Data to Agreement Sheet | Syncs "Joined" candidates from the Offers tab to the Agreement tab, merging in personal details |
| 4. Generate Employment Agreements | Creates Employment Agreement + Consent Letter + COC as PDFs, picking the right template by level and bonus type |
| 5. Push Data to Onboarding Sheet | Header-maps and pushes joined candidates to your onboarding spreadsheet — duplicates skipped automatically |

### Consultant Offers
Same flow for contract/consultant hires with separate templates and Drive folders.

### Utilities
- **Setup Employee Dropdowns** — Loads your employee list into HRBP, Captain, and CXO dropdown columns
- **Norm Code Auto-fill** — Auto-populates compensation norm fields when a norm code is typed in column A

---

## How It Works

The engine reads rows from your Offer Master sheet and processes any row where you've set the trigger columns (`Offer Status` + `Generate = Yes`). It copies a Google Doc template, fills in all placeholders using `##PlaceholderName##` syntax, exports to PDF, and saves to the right Drive folder — all in a single click.

```
Offer Master Sheet
  └── Row marked "Generate = Yes"
        ├── Copy Google Doc template
        ├── Replace ##placeholders## with candidate data
        ├── Export as PDF → save to Drive folder
        └── Show results summary (Created / Skipped / Errors)
```

---

## Setup

### Step 1 — Prepare your Google Sheets and Drive

You'll need:
- **Offer Master Sheet** — main spreadsheet with offer data
- **Personal Details Sheet** — separate sheet with candidate personal info (address, father's name, gender, etc.) keyed by email
- **Onboarding Sheet** — where joined candidates are pushed
- **Drive folders** — one per document type (checklists, offer emails, agreements, etc.)
- **Google Doc templates** — one per offer/agreement type, using `##PlaceholderName##` syntax

### Step 2 — Configure `Code.gs`

Open `Code.gs` and fill in every value in the `CONFIG` block at the top:

```javascript
var CONFIG = {
  // ── Spreadsheet IDs ──────────────────────────────────────────
  MASTER_ID:       'YOUR_OFFER_MASTER_SHEET_ID',
  PERSONAL_ID:     'YOUR_PERSONAL_DETAILS_SHEET_ID',
  ONBOARDING_ID:   'YOUR_ONBOARDING_SHEET_ID',

  // ── Tab Names (must match exactly) ───────────────────────────
  TAB_OFFERS:      'Offers',           // your main offers tab
  TAB_NORM:        'Norm Codes',       // compensation norm lookup tab
  TAB_EMP:         'Employees',        // employee name + code tab
  TAB_AGREEMENT:   'Agreement Data',   // TA/HR ops agreement tab
  TAB_PERSONAL:    'Form Responses 1', // personal details tab
  TAB_ONBOARDING:  'Onboarding Data',  // target onboarding tab
  TAB_CONSULTANT:  'Consultant Offers',// consultant offers tab

  // ── Company Info ─────────────────────────────────────────────
  COMPANY_NAME:    'Your Company',
  HR_EMAIL:        'hr@yourcompany.com',
  HR_NAME:         'HR Team',

  // ── Drive Folder IDs ─────────────────────────────────────────
  DIR_CHECKLIST:   'FOLDER_ID_CHECKLISTS',
  DIR_EMAIL:       'FOLDER_ID_OFFER_EMAILS',
  DIR_AGREEMENT:   'FOLDER_ID_AGREEMENTS',
  DIR_SENIOR_WB:   'FOLDER_ID_SENIOR_WITH_BONUS',
  DIR_SENIOR_NB:   'FOLDER_ID_SENIOR_NO_BONUS',
  DIR_JUNIOR_WB:   'FOLDER_ID_JUNIOR_WITH_BONUS',
  DIR_JUNIOR_NB:   'FOLDER_ID_JUNIOR_NO_BONUS',
  DIR_CONSULTANT:  'FOLDER_ID_CONSULTANTS',

  // ── Google Doc Template IDs ───────────────────────────────────
  TPL_CHECKLIST:   'TEMPLATE_ID_CHECKLIST',
  TPL_OE_SR_NB:    'TEMPLATE_ID_OFFER_EMAIL_SENIOR_NO_BONUS',
  TPL_OE_SR_WB:    'TEMPLATE_ID_OFFER_EMAIL_SENIOR_WITH_BONUS',
  TPL_OE_JR_NB:    'TEMPLATE_ID_OFFER_EMAIL_JUNIOR_NO_BONUS',
  TPL_OE_JR_WB:    'TEMPLATE_ID_OFFER_EMAIL_JUNIOR_WITH_BONUS',
  TPL_AG_SR_NB:    'TEMPLATE_ID_AGREEMENT_SENIOR_NO_BONUS',
  TPL_AG_SR_WB:    'TEMPLATE_ID_AGREEMENT_SENIOR_WITH_BONUS',
  TPL_AG_JR_NB:    'TEMPLATE_ID_AGREEMENT_JUNIOR_NO_BONUS',
  TPL_AG_JR_WB:    'TEMPLATE_ID_AGREEMENT_JUNIOR_WITH_BONUS',
  TPL_CONSENT:     'TEMPLATE_ID_CONSENT_LETTER',
  TPL_COC:         'TEMPLATE_ID_COC_LETTER',
  TPL_CONSULTANT:  'TEMPLATE_ID_CONSULTANT_DEFAULT',

  // ── Column Indices (0-based) ──────────────────────────────────
  // Update these to match your sheet's column layout
  COL: {
    REQ_CODE:       0,
    JOINING_DATE:   2,
    NOTICE_PERIOD:  3,
    NAME:           4,
    LEVEL:          5,
    DESIGNATION:    6,
    YTP:            7,
    LAST_CTC:       8,
    LAST_VAR:       9,
    LAST_STOCKS:    10,
    EXPECTED_CTC:   11,
    COMPA:          12,
    IDEAL_CTC:      13,
    NEXT_CTC:       14,
    OFFERED_CTC:    15,
    JOINING_BONUS:  16,
    TP_RATING:      17,
    ESOP_PCT:       21,
    ESOP_VALUE:     20,
    HIKE_PCT:       22,
    APPRAISAL:      23,
    PRODUCT_BU:     27,
    LEAGUE:         29,
    CLUB:           30,
    MINI_CLUB:      31,
    SOURCE:         34,
    SUB_SOURCE:     35,
    SOURCE_COST:    36,
    NOTION_LINK:    37,
    LEVER_LINK:     38,
    TOTAL_EXP:      40,
    LAST_COMPANY:   41,
    LAST_CO_EXP:    42,
    RELOCATION:     43,
    TA_OWNER:       44,
    TA_CAPTAIN:     45,
    HRBP:           46,
    HIRING_CAPTAIN: 47,
    CXO:            48,
    OFFER_STATUS:   50,  // trigger column
    GENERATE:       51,  // set to "Yes" to process
    EMAIL:          52
  },

  // ── Level Threshold ───────────────────────────────────────────
  // Candidates at or above this level use "Senior" templates
  SENIOR_LEVEL_THRESHOLD: 7,

  // ── Salary Breakup Policy ─────────────────────────────────────
  SALARY: {
    BASIC_PCT:        0.30,   // Basic as % of CTC
    BASIC_MIN:        252000, // Minimum annual basic
    HRA_PCT:          0.15,   // HRA as % of CTC
    LTA_ANNUAL:       2400,
    FOOD_ANNUAL:      72000,
    PF_ANNUAL:        21600
  }
};
```

**How to find IDs:**
- Sheet ID: `docs.google.com/spreadsheets/d/`**`THIS_PART`**`/edit`
- Folder ID: `drive.google.com/drive/folders/`**`THIS_PART`**
- Doc Template ID: `docs.google.com/document/d/`**`THIS_PART`**`/edit`

### Step 3 — Deploy to Apps Script

1. Open your Offer Master Google Sheet
2. Go to **Extensions → Apps Script**
3. Delete any existing code and paste the full contents of `Code.gs`
4. Click **Save** (Ctrl+S)
5. Reload the sheet — a **"Offer Automations"** menu will appear

### Step 4 — Install the onEdit Trigger

This enables auto-fill of norm code fields when you type a code in column A.

1. In Apps Script, click the **Triggers** icon (clock) in the left sidebar
2. Click **+ Add Trigger**
3. Choose: Function = `onEditAutoFillNormCode`, Event = `On edit`
4. Save and authorize

### Step 5 — Authorize Permissions

On first run, Google will ask you to grant access to Sheets, Drive, Docs, and Gmail. All required.

---

## How to Use

### Generate Offer Documents

1. Find the candidate row in your Offers sheet
2. Set the **Offer Status** column to the trigger value (e.g. `Create Checklist`)
3. Set the **Generate** column to `Yes`
4. Click **Offer Automations → FTE Offers → 1. Generate Offer Checklist**
5. A results modal shows Created / Skipped / Errors

### Generate Employment Agreements

1. After a candidate joins, run **Step 3** (Move Data to Agreement Sheet)
2. In the Agreement tab, set the **Create Agreement** column to `Yes`
3. Run **Step 4** — Agreement + Consent Letter + COC are saved as PDFs

### Push to Onboarding Sheet

Run **Step 5** — the script auto-maps headers between sheets and skips duplicates (matched by email).

---

## Document Templates

Templates use `##PlaceholderName##` syntax. The engine replaces all placeholders before exporting to PDF.

### Checklist / Offer Email Placeholders

| Placeholder | Value |
|-------------|-------|
| `##Name##` | Candidate full name |
| `##FirstName##` | First name only |
| `##Designation##` | Job title |
| `##Level##` | Band/level |
| `##Offered Fixed CTC##` | CTC formatted with commas |
| `##OfferedFixedCTCInWords##` | e.g. "INR Twenty Five Lakh Only" |
| `##Joining Date##` | Formatted join date |
| `##Retention Bonus##` / `##Joining Bonus##` | Bonus amount |
| `##Mbasic##` / `##Ybasic##` | Monthly / yearly basic salary |
| `##Mhra##` / `##Yhra##` | Monthly / yearly HRA |
| `##MEntA##` / `##YEntA##` | Monthly / yearly flexible/other allowance |
| `##Mctc##` | Monthly CTC |
| `##ValidityDate##` | Offer expiry date (join date + 3 days) |

### Agreement Additional Placeholders

| Placeholder | Value |
|-------------|-------|
| `##Full Name##` | Name as per PAN |
| `##Title##` | Mr. / Ms. |
| `##Father Name##` | Father's name |
| `##EmailID##` | Personal email |
| `##PhoneNumber##` | Phone number |
| `##Registered Address##` | Full address |
| `##PermCity##` / `##PermState##` / `##PermPinCode##` | Address components |

---

## Salary Breakup Logic

Calculated automatically from CTC using the policy defined in `CONFIG.SALARY`:

```
Basic       = max(CTC × BASIC_PCT, BASIC_MIN)
HRA         = CTC × HRA_PCT
LTA         = LTA_ANNUAL
Food Allow  = FOOD_ANNUAL
PF          = PF_ANNUAL (if applicable)
Flexible    = CTC − (Basic + HRA + LTA + Food + PF)
```

Adjust the percentages and fixed amounts in `CONFIG.SALARY` to match your company's compensation policy.

---

## Trigger Column Values

By default the script looks for these values in the `Offer Status` column:

| Status Value | Triggers |
|--------------|---------|
| Contains `checklist` | Offer Checklist generation |
| `Create Offer Email` | Offer Email generation |
| `Joined` | Data transfer to Agreement sheet |

You can change these string matches in the respective functions.

---

## File Structure

```
ta-automation-engine/
├── Code.gs      ← Paste this into Google Apps Script
└── README.md    ← This file
```

---

## Known Issues / Planned Improvements

- [ ] Move column indices to `CONFIG.COL` (done) — but consider reading headers dynamically for zero-config setup
- [ ] `words_()` supports up to 999 crore — extend if your CTC figures exceed this
- [ ] `consultantoffer`, `ctccalculator`, `updatehikeandstocks` — stub implementations, not yet built
- [ ] `sendOfferEmail_()` is defined but not wired into the flow — activate when ready
- [ ] Add a dry-run mode that previews what will be generated without creating files

---

## Requirements

- Google Account with edit access to all referenced sheets and Drive folders
- Google Docs templates for each offer/agreement type
- Apps Script enabled on your Google Workspace (enabled by default for most orgs)

No external dependencies. No npm. No server. Just Apps Script.

---

## License

MIT — use freely, modify as needed, attribution appreciated but not required.
