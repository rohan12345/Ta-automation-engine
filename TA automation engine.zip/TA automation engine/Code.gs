/* ================================================================
   TA Automation Engine v6.0
   Automates offer checklists, offer emails, employment agreements,
   and onboarding data pushes — all from your Google Sheet.

   SETUP: Fill in every value in the CONFIG block below, then
   paste this file into Extensions → Apps Script and save.
   ================================================================ */

// ================================================================
// SECTION 1: CONFIGURATION — edit everything here
// ================================================================

var CONFIG = {
  // ── Spreadsheet IDs ──────────────────────────────────────────
  MASTER_ID:       'YOUR_OFFER_MASTER_SHEET_ID',
  PERSONAL_ID:     'YOUR_PERSONAL_DETAILS_SHEET_ID',
  ONBOARDING_ID:   'YOUR_ONBOARDING_SHEET_ID',

  // ── Tab Names (must match exactly) ───────────────────────────
  TAB_OFFERS:      'Offers',
  TAB_NORM:        'Norm Codes',
  TAB_EMP:         'Employees',
  TAB_AGREEMENT:   'Agreement Data',
  TAB_PERSONAL:    'Form Responses 1',
  TAB_ONBOARDING:  'Onboarding Data',
  TAB_CONSULTANT:  'Consultant Offers',

  // ── Company Info ─────────────────────────────────────────────
  COMPANY_NAME:    'Your Company',
  HR_EMAIL:        'hr@yourcompany.com',
  HR_NAME:         'HR Team',

  // ── Drive Folder IDs ─────────────────────────────────────────
  DIR_CHECKLIST:   'FOLDER_ID_CHECKLISTS',
  DIR_EMAIL:       'FOLDER_ID_OFFER_EMAILS',
  DIR_AGREEMENT:   'FOLDER_ID_AGREEMENTS',
  DIR_SENIOR_WB:   'FOLDER_ID_SENIOR_WITH_BONUS',
  DIR_SENIOR_NB:   'FOLDER_ID_SENIOR_NO_BONUS',
  DIR_JUNIOR_WB:   'FOLDER_ID_JUNIOR_WITH_BONUS',
  DIR_JUNIOR_NB:   'FOLDER_ID_JUNIOR_NO_BONUS',
  DIR_CONSULTANT:  'FOLDER_ID_CONSULTANTS',

  // ── Google Doc Template IDs ───────────────────────────────────
  TPL_CHECKLIST:   'TEMPLATE_ID_CHECKLIST',
  TPL_OE_SR_NB:    'TEMPLATE_ID_OFFER_EMAIL_SENIOR_NO_BONUS',
  TPL_OE_SR_WB:    'TEMPLATE_ID_OFFER_EMAIL_SENIOR_WITH_BONUS',
  TPL_OE_JR_NB:    'TEMPLATE_ID_OFFER_EMAIL_JUNIOR_NO_BONUS',
  TPL_OE_JR_WB:    'TEMPLATE_ID_OFFER_EMAIL_JUNIOR_WITH_BONUS',
  TPL_AG_SR_NB:    'TEMPLATE_ID_AGREEMENT_SENIOR_NO_BONUS',
  TPL_AG_SR_WB:    'TEMPLATE_ID_AGREEMENT_SENIOR_WITH_BONUS',
  TPL_AG_JR_NB:    'TEMPLATE_ID_AGREEMENT_JUNIOR_NO_BONUS',
  TPL_AG_JR_WB:    'TEMPLATE_ID_AGREEMENT_JUNIOR_WITH_BONUS',
  TPL_CONSENT:     'TEMPLATE_ID_CONSENT_LETTER',
  TPL_COC:         'TEMPLATE_ID_COC_LETTER',
  TPL_CONSULTANT:  'TEMPLATE_ID_CONSULTANT_DEFAULT',

  // ── Column Indices (0-based) ──────────────────────────────────
  // Update to match your sheet layout. Column A = 0, B = 1, etc.
  COL: {
    REQ_CODE:       0,
    JOINING_DATE:   2,
    NOTICE_PERIOD:  3,
    NAME:           4,
    LEVEL:          5,
    DESIGNATION:    6,
    YTP:            7,
    LAST_CTC:       8,
    LAST_VAR:       9,
    LAST_STOCKS:    10,
    EXPECTED_CTC:   11,
    COMPA:          12,
    IDEAL_CTC:      13,
    NEXT_CTC:       14,
    OFFERED_CTC:    15,
    JOINING_BONUS:  16,
    TP_RATING:      17,
    ESOP_PCT:       21,
    ESOP_VALUE:     20,
    HIKE_PCT:       22,
    APPRAISAL:      23,
    PRODUCT_BU:     27,
    LEAGUE:         29,
    CLUB:           30,
    MINI_CLUB:      31,
    SOURCE:         34,
    SUB_SOURCE:     35,
    SOURCE_COST:    36,
    NOTION_LINK:    37,
    LEVER_LINK:     38,
    TOTAL_EXP:      40,
    LAST_COMPANY:   41,
    LAST_CO_EXP:    42,
    RELOCATION:     43,
    TA_OWNER:       44,
    TA_CAPTAIN:     45,
    HRBP:           46,
    HIRING_CAPTAIN: 47,
    CXO:            48,
    OFFER_STATUS:   50,
    GENERATE:       51,
    EMAIL:          52
  },

  // ── Level Threshold ───────────────────────────────────────────
  // Candidates at or above this level use "Senior" templates
  SENIOR_LEVEL_THRESHOLD: 7,

  // ── Salary Breakup Policy ─────────────────────────────────────
  SALARY: {
    BASIC_PCT:    0.30,
    BASIC_MIN:    252000,
    HRA_PCT:      0.15,
    LTA_ANNUAL:   2400,
    FOOD_ANNUAL:  72000,
    PF_ANNUAL:    21600
  }
};

// Convenience alias
var COL = CONFIG.COL;


// ================================================================
// SECTION 2: MENU
// ================================================================

function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('Offer Automations')
    .addSubMenu(ui.createMenu('FTE Offers')
      .addItem('1. Generate Offer Checklist',        'offercreatorind')
      .addItem('2. Generate Offer Email',            'offerEmailCreator')
      .addSeparator()
      .addItem('3. Move Data to Agreement Sheet',    'agreementDataTransfer')
      .addItem('4. Generate Employment Agreements',  'generateFTEAgreements')
      .addItem('5. Push Data to Onboarding Sheet',   'pushToOnboardingSheet')
      .addSeparator()
      .addItem('Update Auto Fields',                 'updatehikeandstocks')
      .addItem('Start Post Offer',                   'downalertpop')
      .addItem('Update Onboarding',                  'runOnboardingUpdates'))
    .addSubMenu(ui.createMenu('Consultant Offers')
      .addItem('1. Create Consultant Offer',         'consultantoffer')
      .addItem('2. Generate Consultant Agreements',  'generateConsultantAgreements')
      .addSeparator()
      .addItem('Update Auto Fields',                 'updateautofieldsconsultants')
      .addItem('Start Post Offer',                   'poeInitiatorConsultants')
      .addItem('Update Consultant Onboarding',       'runOnboardingUpdatesCons'))
    .addSubMenu(ui.createMenu('Setup & Tools')
      .addItem('Setup Employee Dropdowns',           'setupEmployeeDropdowns')
      .addItem('CTC Calculator',                     'ctccalculator'))
    .addToUi();
}


// ================================================================
// SECTION 3: CORE ENGINE
// ================================================================

function openSheet_(id) {
  try { return SpreadsheetApp.openById(id); }
  catch (e) { _log('FAIL openSheet_ ' + id + ': ' + e); return null; }
}

function getTab_(ss, name) {
  if (!ss) return null;
  var tab = ss.getSheetByName(name);
  if (!tab) {
    var available = ss.getSheets().map(function(s) { return '"' + s.getName() + '"'; }).join(', ');
    _log('Tab "' + name + '" not found. Available: ' + available);
  }
  return tab;
}

function requireTab_(ss, name, label) {
  var tab = getTab_(ss, name);
  if (!tab) {
    SpreadsheetApp.getUi().alert('Sheet Error',
      'Cannot find tab "' + name + '" in ' + (label || 'spreadsheet') + '.\n\n'
      + 'Available tabs:\n' + ss.getSheets().map(function(s) { return '  ' + s.getName(); }).join('\n'),
      SpreadsheetApp.getUi().ButtonSet.OK);
  }
  return tab;
}

function retry_(fn, n) {
  n = n || 3;
  for (var attempt = 1; attempt <= n; attempt++) {
    try { return fn(); }
    catch (e) {
      _log('retry_ attempt ' + attempt + '/' + n + ': ' + e);
      if (attempt === n) throw e;
      Utilities.sleep(1000 * attempt);
    }
  }
}

function _log(msg) {
  Logger.log('[TA-Engine ' + new Date().toISOString() + '] ' + msg);
}

function str_(row, i) {
  if (!row || i < 0 || i >= row.length || row[i] == null) return '';
  return String(row[i]).trim();
}

function num_(row, i) {
  var v = str_(row, i);
  if (!v) return 0;
  var n = parseFloat(v.replace(/[^0-9.\-]/g, ''));
  return isNaN(n) ? 0 : n;
}

function escRx_(s) {
  return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
}

function safeReplace_(body, placeholder, value) {
  try { body.replaceText(escRx_(placeholder), String(value)); } catch (e) { /* skip */ }
}

function replaceAll_(body, pairs) {
  for (var i = 0; i < pairs.length; i++) {
    safeReplace_(body, pairs[i][0], pairs[i][1]);
  }
}


// ================================================================
// SECTION 4: UI ENGINE
// ================================================================

function toast_(msg, title, sec) {
  try { SpreadsheetApp.getActiveSpreadsheet().toast(msg, title || '', sec || 4); } catch (e) {}
}

function showSummary_(title, results, type) {
  var palette = {
    checklist: { accent: '#007AFF', light: '#EBF5FF', icon: '&#128203;', label: 'Offer Checklist' },
    email:     { accent: '#5856D6', light: '#F3F2FF', icon: '&#9993;',   label: 'Offer Email' },
    agreement: { accent: '#34C759', light: '#EAFBEF', icon: '&#128196;', label: 'Employment Agreement' },
    transfer:  { accent: '#FF9500', light: '#FFF8EB', icon: '&#128230;', label: 'Data Transfer' },
    push:      { accent: '#AF52DE', light: '#F9F0FF', icon: '&#128228;', label: 'Data Push' }
  };
  var p = palette[type] || palette.checklist;
  var total = results.success.length + results.errors.length + results.skipped;

  var css = '<style>'
    + '* { margin:0; padding:0; box-sizing:border-box; }'
    + 'body { font-family: -apple-system, "SF Pro Display", "Segoe UI", Roboto, sans-serif; }'
    + '.hdr { background:' + p.accent + '; color:#fff; padding:28px 32px 24px; }'
    + '.hdr h1 { font-size:22px; font-weight:600; letter-spacing:-0.3px; }'
    + '.hdr p  { font-size:13px; opacity:0.8; margin-top:4px; }'
    + '.stats  { display:flex; padding:20px 24px; background:' + p.light + '; border-bottom:1px solid rgba(0,0,0,0.06); }'
    + '.stat   { flex:1; text-align:center; }'
    + '.stat .n { font-size:28px; font-weight:700; line-height:1; }'
    + '.stat .l { font-size:10px; text-transform:uppercase; letter-spacing:0.8px; color:#8E8E93; margin-top:4px; }'
    + '.section { padding:16px 24px 8px; }'
    + '.section-title { font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.6px; margin-bottom:10px; }'
    + '.card { display:flex; align-items:center; padding:12px 14px; margin-bottom:6px; border-radius:12px; }'
    + '.card .dot  { width:8px; height:8px; border-radius:50%; margin-right:12px; flex-shrink:0; }'
    + '.card .info { flex:1; }'
    + '.card .name   { font-size:14px; font-weight:500; color:#1C1C1E; }'
    + '.card .detail { font-size:11px; color:#8E8E93; margin-top:2px; }'
    + '.ok .dot { background:#34C759; } .ok { background:#F0FDF4; }'
    + '.err .dot { background:#FF3B30; } .err { background:#FEF2F2; }'
    + '.empty { padding:40px 24px; text-align:center; }'
    + '.empty .big { font-size:40px; margin-bottom:8px; }'
    + '.empty .msg  { font-size:14px; color:#8E8E93; }'
    + '.foot { padding:14px 24px; text-align:center; border-top:1px solid rgba(0,0,0,0.06); }'
    + '.foot span { font-size:10px; color:#C7C7CC; }'
    + '</style>';

  var h = css
    + '<div class="hdr"><h1>' + p.icon + '  ' + p.label + '</h1><p>' + total + ' rows processed</p></div>'
    + '<div class="stats">'
    + '<div class="stat"><div class="n" style="color:#34C759">' + results.success.length + '</div><div class="l">Created</div></div>'
    + '<div class="stat"><div class="n" style="color:#C7C7CC">' + results.skipped + '</div><div class="l">Skipped</div></div>'
    + '<div class="stat"><div class="n" style="color:#FF3B30">' + results.errors.length + '</div><div class="l">Errors</div></div>'
    + '</div>';

  if (results.success.length) {
    h += '<div class="section"><div class="section-title" style="color:#34C759">Created</div>';
    results.success.forEach(function(s) {
      h += '<div class="card ok"><div class="dot"></div><div class="info"><div class="name">' + esc_(s.name) + '</div><div class="detail">' + esc_(s.detail) + '</div></div></div>';
    });
    h += '</div>';
  }
  if (results.errors.length) {
    h += '<div class="section"><div class="section-title" style="color:#FF3B30">Errors</div>';
    results.errors.forEach(function(er) {
      h += '<div class="card err"><div class="dot"></div><div class="info"><div class="name">' + esc_(er.name) + '</div><div class="detail">' + esc_(er.error) + '</div></div></div>';
    });
    h += '</div>';
  }
  if (!results.success.length && !results.errors.length) {
    h += '<div class="empty"><div class="big">&#128269;</div><div class="msg">No matching rows found.<br>Check Offer Status and Generate columns.</div></div>';
  }

  var ts = new Date().toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
  h += '<div class="foot"><span>TA Automation Engine v6.0 &mdash; ' + ts + '</span></div>';

  var height = 260 + Math.min(results.success.length + results.errors.length, 6) * 56;
  SpreadsheetApp.getUi().showModalDialog(
    HtmlService.createHtmlOutput(h).setWidth(440).setHeight(Math.min(height, 620)), title);
}

function esc_(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }


// ================================================================
// SECTION 5: NORM CODE AUTO-FILL (installable onEdit trigger)
// ================================================================

function onEditAutoFillNormCode(e) {
  try {
    var sh = e.source.getActiveSheet();
    var r  = e.range;
    if (sh.getName() !== CONFIG.TAB_OFFERS || r.getColumn() !== 1 || r.getRow() < 2) return;

    var code = String(r.getValue()).trim();
    if (!code) return;

    var normSh = e.source.getSheetByName(CONFIG.TAB_NORM);
    if (!normSh) return;

    var codes   = normSh.getRange('I7:I206').getValues();
    var details = normSh.getRange('C7:G206').getValues();

    for (var i = 0; i < codes.length; i++) {
      if (String(codes[i][0]).trim() === code) {
        sh.getRange(r.getRow(), 28, 1, 5).setValues([[
          details[i][0]||'', details[i][1]||'', details[i][2]||'',
          details[i][3]||'', details[i][4]||''
        ]]);
        return;
      }
    }
  } catch (err) { _log('onEdit norm: ' + err); }
}


// ================================================================
// SECTION 6: EMPLOYEE DROPDOWNS
// ================================================================

function setupEmployeeDropdowns() {
  var ui = SpreadsheetApp.getUi();
  toast_('Loading employee list...', 'Dropdown Setup');

  var ss = openSheet_(CONFIG.MASTER_ID);
  if (!ss) { ui.alert('Cannot open master sheet.'); return; }

  var empTab = requireTab_(ss, CONFIG.TAB_EMP, 'Master Sheet');
  var offTab = requireTab_(ss, CONFIG.TAB_OFFERS, 'Master Sheet');
  if (!empTab || !offTab) return;

  var names = empTab.getRange(2, 2, empTab.getLastRow() - 1, 1).getValues()
    .map(function(r) { return String(r[0]).trim(); })
    .filter(function(n) { return n !== ''; });

  if (!names.length) { ui.alert('No employees found in "' + CONFIG.TAB_EMP + '".'); return; }

  var rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(names, true).setAllowInvalid(false).build();
  var last = Math.max(offTab.getLastRow(), 100);
  // Columns AU (47), AV (48), AW (49) — HRBP, Captain, CXO
  [COL.HRBP + 1, COL.HIRING_CAPTAIN + 1, COL.CXO + 1].forEach(function(col) {
    offTab.getRange(2, col, last - 1, 1).setDataValidation(rule);
  });

  ui.alert('Done!', names.length + ' employees loaded into dropdown columns.', ui.ButtonSet.OK);
}

function lookupEmpCode_(name, empData) {
  if (!name) return '';
  var target = name.toString().trim().toLowerCase();
  for (var i = 0; i < empData.length; i++) {
    if (String(empData[i][1]).trim().toLowerCase() === target) return String(empData[i][0]).trim();
  }
  return '';
}


// ================================================================
// SECTION 7: OFFER CHECKLIST GENERATION
// ================================================================

function offercreatorind() {
  var R = { success: [], errors: [], skipped: 0 };
  try {
    toast_('Loading data...', 'Checklist');
    var ss   = openSheet_(CONFIG.MASTER_ID);
    var pdSS = openSheet_(CONFIG.PERSONAL_ID);
    if (!ss || !pdSS) { SpreadsheetApp.getUi().alert('Cannot open spreadsheets.'); return; }

    var src = requireTab_(ss,   CONFIG.TAB_OFFERS,   'Master');
    var pd  = requireTab_(pdSS, CONFIG.TAB_PERSONAL, 'Personal Details');
    if (!src || !pd) return;

    var data   = src.getDataRange().getValues();
    var pdData = pd.getDataRange().getValues();

    for (var i = 1; i < data.length; i++) {
      var row    = data[i];
      var status = str_(row, COL.OFFER_STATUS).toLowerCase();
      var gen    = str_(row, COL.GENERATE);
      if (!status.includes('checklist') || gen !== 'Yes') { R.skipped++; continue; }

      var name = str_(row, COL.NAME) || 'Row ' + (i + 1);
      try {
        toast_('Creating: ' + name, 'Checklist ' + (R.success.length + 1));
        var res = buildChecklist_(row, pdData);
        R.success.push({ name: res.name, detail: 'L' + str_(row, COL.LEVEL) + ' - ' + str_(row, COL.DESIGNATION).split('-')[0].trim() });
      } catch (e) { R.errors.push({ name: name, error: e.toString().substring(0, 90) }); }
    }
    showSummary_('Offer Checklist', R, 'checklist');
  } catch (e) { SpreadsheetApp.getUi().alert('Error: ' + e); }
}

function buildChecklist_(row, pdData) {
  var name = str_(row, COL.NAME);
  if (!name) return { name: 'Unknown' };

  var desg    = str_(row, COL.DESIGNATION).split('-')[0].trim();
  var ctc     = num_(row, COL.OFFERED_CTC);
  var rb      = num_(row, COL.JOINING_BONUS);
  var esops   = num_(row, COL.ESOP_VALUE);
  var compa   = num_(row, COL.COMPA);
  var hike    = parseHikeOrPercent_(str_(row, COL.HIKE_PCT));
  var esopPct = (esops > 0) ? parseHikeOrPercent_(str_(row, COL.ESOP_PCT)) : '0';
  var compaVal = (compa > 0 && ctc > 0) ? pf2_(ctc / compa) : 'N/A';

  var doc = retry_(function() {
    return DriveApp.getFileById(CONFIG.TPL_CHECKLIST)
      .makeCopy(name + ' - Offer Checklist', DriveApp.getFolderById(CONFIG.DIR_CHECKLIST));
  });
  var body = DocumentApp.openById(doc.getId()).getBody();

  var pairs = [
    ['##ProductBU##',              str_(row, COL.PRODUCT_BU)],
    ['##ReqCode##',                str_(row, COL.REQ_CODE)],
    ['##Name##',                   name],
    ['##Designation##',            desg],
    ['##Level##',                  str_(row, COL.LEVEL)],
    ['##YTP##',                    str_(row, COL.YTP)],
    ['##League##',                 str_(row, COL.LEAGUE)],
    ['##Club##',                   str_(row, COL.CLUB)],
    ['##MiniClub##',               str_(row, COL.MINI_CLUB)],
    ['##NotionLink##',             str_(row, COL.NOTION_LINK) || 'NA'],
    ['##LeverLink##',              str_(row, COL.LEVER_LINK)],
    ['##AverageInterviewRating##', str_(row, COL.TP_RATING)  || 'NA'],
    ['##Last CTC##',               num_(row, COL.LAST_CTC) > 0 ? fmtLPA_(num_(row, COL.LAST_CTC)) + ' LPA' : 'NA'],
    ['##LastVarPay##',             num_(row, COL.LAST_VAR) > 0 ? '+ ' + fmtLPA_(num_(row, COL.LAST_VAR)) + ' LPA (variable)' : ''],
    ['##LastStocks##',             num_(row, COL.LAST_STOCKS) > 0 ? '+ ' + fmtLPA_(num_(row, COL.LAST_STOCKS)) + ' LPA (stocks)' : ''],
    ['##Offered Fixed CTC##',      fmtLPA_(ctc)],
    ['##Offered ESOPs##',          fmtLPA_(esops)],
    ['##Retention Bonus##',        rb > 0 ? '+ INR ' + fmtLPA_(rb) + ' L (Joining Bonus)' : ''],
    ['##Joining Date##',           fmtDate_(row[COL.JOINING_DATE])],
    ['##Notice Period##',          str_(row, COL.NOTICE_PERIOD)],
    ['##Source##',                 str_(row, COL.SOURCE)],
    ['##Sub-Source##',             str_(row, COL.SUB_SOURCE)],
    ['##Source-Cost##',            str_(row, COL.SOURCE_COST) || '0'],
    ['##Total Experience##',       str_(row, COL.TOTAL_EXP)],
    ['##Last Company##',           str_(row, COL.LAST_COMPANY)],
    ['##Last Company Experience##',str_(row, COL.LAST_CO_EXP) || ''],
    ['##Relocation Expenses##',    str_(row, COL.RELOCATION) === 'Yes' ? 'Yes' : 'No'],
    ['##Connections##',            'TA to manually add, if any'],
    ['##OfferedDate##',            fmtDate_(new Date())],
    ['##IdealFixedCTC##',          fmtLPA_(num_(row, COL.IDEAL_CTC))],
    ['##NextYTP##',                parseInt(str_(row, COL.YTP)) > 2 ? '2+' : '3+'],
    ['##NextRangeCTC##',           fmtLPA_(num_(row, COL.NEXT_CTC))],
    ['##OfferedCompaValue##',      compaVal],
    ['##PercentageCompRaise##',    hike],
    ['##Expected CTC##',          fmtLPA_(num_(row, COL.EXPECTED_CTC))],
    ['##AppraisalEligibility##',   str_(row, COL.APPRAISAL) || 'TBD'],
    ['##OptionalJBComponentNote##',''],
    ['##TPRating##',               str_(row, COL.TP_RATING) || 'NA'],
    ['##TAOwner##',                str_(row, COL.TA_OWNER)  || 'TA Team'],
    ['##TACaptain##',              str_(row, COL.TA_CAPTAIN)|| 'Captain'],
    ['##HRBP##',                   str_(row, COL.HRBP)],
    ['##Hiring Captain##',         str_(row, COL.HIRING_CAPTAIN)]
  ];

  replaceAll_(body, pairs);

  if (esopPct === 'NA' || esopPct === '0') {
    safeReplace_(body, '##ESOPPercentage##% of fixed CTC', esopPct === '0' ? '0' : 'NA');
  } else {
    safeReplace_(body, '##ESOPPercentage##', esopPct);
  }

  DocumentApp.openById(doc.getId()).saveAndClose();
  toPdf_(doc.getId(), name + ' - Offer Checklist', DriveApp.getFolderById(CONFIG.DIR_CHECKLIST));
  return { name: name };
}


// ================================================================
// SECTION 8: OFFER EMAIL GENERATION
// ================================================================

function offerEmailCreator() {
  var R = { success: [], errors: [], skipped: 0 };
  try {
    toast_('Loading data...', 'Offer Email');
    var ss = openSheet_(CONFIG.MASTER_ID);
    if (!ss) { SpreadsheetApp.getUi().alert('Cannot open master sheet.'); return; }
    var src = requireTab_(ss, CONFIG.TAB_OFFERS, 'Master');
    if (!src) return;

    var data   = src.getDataRange().getValues();
    var folder = DriveApp.getFolderById(CONFIG.DIR_EMAIL);

    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      if (str_(row, COL.OFFER_STATUS) !== 'Create Offer Email' || str_(row, COL.GENERATE) !== 'Yes') { R.skipped++; continue; }
      var name = str_(row, COL.NAME) || 'Row ' + (i + 1);
      try {
        var lvl = num_(row, COL.LEVEL), jb = num_(row, COL.JOINING_BONUS);
        var sr  = lvl >= CONFIG.SENIOR_LEVEL_THRESHOLD, hb = jb > 0;
        var tpl = sr ? (hb ? CONFIG.TPL_OE_SR_WB : CONFIG.TPL_OE_SR_NB)
                     : (hb ? CONFIG.TPL_OE_JR_WB : CONFIG.TPL_OE_JR_NB);
        var label = (sr ? 'Senior' : 'Junior') + (hb ? ' + JB' : '');
        var res = buildOfferEmail_(row, tpl, folder);
        R.success.push({ name: res.name, detail: 'L' + str_(row, COL.LEVEL) + ' - ' + comma_(num_(row, COL.OFFERED_CTC)) + ' - ' + label });
      } catch (e) { R.errors.push({ name: name, error: e.toString().substring(0, 90) }); }
    }
    showSummary_('Offer Email', R, 'email');
  } catch (e) { SpreadsheetApp.getUi().alert('Error: ' + e); }
}

function buildOfferEmail_(row, tplId, folder) {
  var name = str_(row, COL.NAME);
  if (!name) return { name: 'Unknown' };

  var ctc = num_(row, COL.OFFERED_CTC), jb = num_(row, COL.JOINING_BONUS);
  var sal = salaryBreakup_(ctc, true);

  var doc = retry_(function() {
    return DriveApp.getFileById(tplId).makeCopy(CONFIG.COMPANY_NAME + ' - Offer Email - ' + name, folder);
  });
  var body = DocumentApp.openById(doc.getId()).getBody();

  var validity = new Date(); validity.setDate(validity.getDate() + 3);
  var pairs = [
    ['##FirstName##',            name.split(' ')[0]],
    ['##Designation##',          str_(row, COL.DESIGNATION)],
    ['##Joining Date##',         fmtDate_(row[COL.JOINING_DATE])],
    ['##Offered Fixed CTC##',    comma_(ctc)],
    ['##OfferedFixedCTCInWords##',inr_(ctc)],
    ['##Retention Bonus##',      comma_(jb)],
    ['##RetentionBonusInWords##', inr_(jb)],
    ['##JoiningBonusInWords##',  inr_(jb)],
    ['##Joining Bonus##',        comma_(jb)],
    ['##ValidityDate##',         fmtDate_(validity)],
    ['##Mbasic##',               comma_(sal.Mb)],
    ['##Ybasic##',               comma_(sal.Yb)],
    ['##Mhra##',                 comma_(sal.Mh)],
    ['##Yhra##',                 comma_(sal.Yh)],
    ['##MEntA##',                comma_(sal.Me)],
    ['##YEntA##',                comma_(sal.Ye)],
    ['##Mctc##',                 comma_(sal.Mc)]
  ];
  replaceAll_(body, pairs);

  DocumentApp.openById(doc.getId()).saveAndClose();
  folder.createFile(DriveApp.getFileById(doc.getId()).getAs('application/pdf'))
    .setName(CONFIG.COMPANY_NAME + ' - Offer Email - ' + name);
  return { name: name };
}


// ================================================================
// SECTION 9: FTE EMPLOYMENT AGREEMENT
// ================================================================

function generateFTEAgreements() {
  var ui = SpreadsheetApp.getUi();
  var R  = { success: [], errors: [], skipped: 0 };

  try {
    toast_('Loading Agreement data...', 'FTE Agreements');
    var ss = openSheet_(CONFIG.MASTER_ID);
    if (!ss) { ui.alert('Cannot open master sheet.'); return; }
    var tab = requireTab_(ss, CONFIG.TAB_AGREEMENT, 'Master');
    if (!tab) return;

    var data = tab.getDataRange().getValues();
    if (data.length < 2) { ui.alert('No data rows found.'); return; }

    // Column index for "Create Agreement" trigger — adjust if needed
    var CREATE_COL = 57;

    var anyYes = false;
    for (var c = 1; c < data.length; c++) {
      if (str_(data[c], CREATE_COL) === 'Yes') { anyYes = true; break; }
    }
    if (!anyYes) {
      ui.alert('Nothing to Generate',
        'Set the "Create Agreement" column to "Yes" for rows you want to process.',
        ui.ButtonSet.OK);
      return;
    }

    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      if (str_(row, CREATE_COL) !== 'Yes') { R.skipped++; continue; }

      var cand = str_(row, 1) || 'Row ' + (i + 1);
      try {
        toast_('Creating: ' + cand, 'Agreement ' + (R.success.length + 1));

        var panName = str_(row, 51) || str_(row, 1);
        var desg    = str_(row, 16), lvl = num_(row, 15);
        var ctc     = num_(row, 25), bonus = num_(row, 26);
        var email   = str_(row, 0)  || str_(row, 40);
        var phone   = str_(row, 39), father = str_(row, 31);
        var doj     = fmtDate_(row[2]);
        var gender  = str_(row, 38);
        var addr    = str_(row, 32), city = str_(row, 33);
        var state   = str_(row, 34), pin  = str_(row, 35);

        var title = gender === 'Male' ? 'Mr. ' : 'Ms. ';
        var sodo  = gender === 'Male' ? 'son'  : 'daughter';
        var sal   = salaryBreakup_(ctc, true);
        var sr    = lvl >= CONFIG.SENIOR_LEVEL_THRESHOLD, hb = bonus > 0;

        var tplId = sr ? (hb ? CONFIG.TPL_AG_SR_WB : CONFIG.TPL_AG_SR_NB)
                       : (hb ? CONFIG.TPL_AG_JR_WB : CONFIG.TPL_AG_JR_NB);
        var dirId = sr ? (hb ? CONFIG.DIR_SENIOR_WB : CONFIG.DIR_SENIOR_NB)
                       : (hb ? CONFIG.DIR_JUNIOR_WB : CONFIG.DIR_JUNIOR_NB);
        var folder = DriveApp.getFolderById(dirId);
        var label  = (sr ? 'Senior' : 'Junior') + (hb ? ' + Bonus' : '');

        var ctcFmt   = comma_(ctc),   ctcWords   = inr_(ctc);
        var bonusFmt = comma_(bonus), bonusWords = inr_(bonus);

        // Employment Agreement
        var agDoc  = retry_(function() { return DriveApp.getFileById(tplId).makeCopy(CONFIG.COMPANY_NAME + ' Agreement: ' + cand); });
        var agBody = DocumentApp.openById(agDoc.getId()).getBody();

        var agPairs = [
          ['##Full Name##',                   panName], ['##FullName##',                panName],
          ['##Designation##',                 desg],    ['##Title##',                   title],
          ['##SoDo##',                        sodo],
          ['##Father Name##',                 father],  ['##FatherName##',              father],
          ['##EmailID##',                     email],   ['##PhoneNumber##',             phone],
          ['##Registered Address##',          addr],    ['##RegisteredAddress##',       addr],
          ['##Date Of Joining##',             doj],     ['##DateOfJoining##',           doj],
          ['##Offered Fixed CTC##',           ctcFmt],  ['##OfferedFixedCTC##',         ctcFmt],
          ['##Offered CTC##',                 ctcFmt],  ['##OfferedCTC##',              ctcFmt],
          ['##Fixed CTC##',                   ctcFmt],  ['##FixedCTC##',                ctcFmt],
          ['##OfferedFixedCTCInWords##',       ctcWords],['##Offered Fixed CTC In Words##', ctcWords],
          ['##OfferedCTCInWords##',            ctcWords],['##CTCInWords##',              ctcWords],
          ['##FixedCTCInWords##',              ctcWords],
          ['##Retention Bonus##',             bonusFmt],['##RetentionBonus##',          bonusFmt],
          ['##Joining Bonus##',               bonusFmt],['##JoiningBonus##',            bonusFmt],
          ['##RetentionBonusInWords##',        bonusWords],['##Retention Bonus In Words##', bonusWords],
          ['##JoiningBonusInWords##',          bonusWords],['##Joining Bonus In Words##',  bonusWords],
          ['##JoiningBonusWords##',            bonusWords],
          ['##Mbasic##', comma_(sal.Mb)], ['##Ybasic##', comma_(sal.Yb)],
          ['##Mhra##',   comma_(sal.Mh)], ['##Yhra##',   comma_(sal.Yh)],
          ['##MEntA##',  comma_(sal.Me)], ['##YEntA##',  comma_(sal.Ye)],
          ['##Mctc##',   comma_(sal.Mc)],
          ['##PermCity##',     city],  ['##PermanentCity##',    city],
          ['##PermState##',    state], ['##PermanentState##',   state],
          ['##PermPinCode##',  pin],   ['##PermanentPinCode##', pin]
        ];
        replaceAll_(agBody, agPairs);
        DocumentApp.openById(agDoc.getId()).saveAndClose();
        toPdfKeep_(agDoc.getId(), CONFIG.COMPANY_NAME + ' Agreement - ' + cand, folder);

        // Consent Letter
        var clDoc  = retry_(function() { return DriveApp.getFileById(CONFIG.TPL_CONSENT).makeCopy(CONFIG.COMPANY_NAME + ' Consent: ' + cand); });
        var clBody = DocumentApp.openById(clDoc.getId()).getBody();
        replaceAll_(clBody, [
          ['##Full Name##', panName], ['##FullName##', panName],
          ['##Designation##', desg],
          ['##Date Of Joining##', doj], ['##DateOfJoining##', doj]
        ]);
        DocumentApp.openById(clDoc.getId()).saveAndClose();
        toPdfKeep_(clDoc.getId(), CONFIG.COMPANY_NAME + ' Consent Letter - ' + cand, folder);

        // COC Consent Letter
        var cocDoc  = retry_(function() { return DriveApp.getFileById(CONFIG.TPL_COC).makeCopy(CONFIG.COMPANY_NAME + ' COC Consent: ' + cand); });
        var cocBody = DocumentApp.openById(cocDoc.getId()).getBody();
        replaceAll_(cocBody, [
          ['##Full Name##', panName], ['##FullName##', panName],
          ['##Designation##', desg],
          ['##Date Of Joining##', doj], ['##DateOfJoining##', doj]
        ]);
        DocumentApp.openById(cocDoc.getId()).saveAndClose();
        toPdfKeep_(cocDoc.getId(), CONFIG.COMPANY_NAME + ' COC Consent - ' + cand, folder);

        tab.getRange(i + 1, CREATE_COL + 1).setValue('Done');
        R.success.push({ name: cand, detail: 'L' + lvl + ' - ' + ctcFmt + ' - ' + label });
      } catch (e) { R.errors.push({ name: cand, error: e.toString().substring(0, 100) }); }
    }
    showSummary_('Employment Agreement', R, 'agreement');
  } catch (e) { ui.alert('Error: ' + e); }
}


// ================================================================
// SECTION 10: CONSULTANT AGREEMENT
// ================================================================

function generateConsultantAgreements() {
  var ui = SpreadsheetApp.getUi();
  var R  = { success: [], errors: [], skipped: 0 };

  try {
    toast_('Loading consultant data...', 'Consultant Agreements');
    var ss   = openSheet_(CONFIG.MASTER_ID);
    var pdSS = openSheet_(CONFIG.PERSONAL_ID);
    if (!ss || !pdSS) { ui.alert('Cannot open spreadsheets.'); return; }

    var consTab = requireTab_(ss,   CONFIG.TAB_CONSULTANT, 'Master');
    var pdTab   = requireTab_(pdSS, CONFIG.TAB_PERSONAL,   'Personal Details');
    if (!consTab || !pdTab) return;

    var pdData = pdTab.getDataRange().getValues();
    var pdMap  = new Map();
    for (var p = 1; p < pdData.length; p++) {
      var pe = String(pdData[p][12]).trim().toLowerCase();
      if (pe) pdMap.set(pe, pdData[p]);
    }

    var allData = consTab.getDataRange().getValues();
    var folder  = DriveApp.getFolderById(CONFIG.DIR_CONSULTANT);

    // Column 43 = "Generate" trigger for consultants — adjust if needed
    var CONS_TRIGGER_COL = 43;

    for (var i = 2; i < allData.length; i++) {
      var row = allData[i];
      if (str_(row, CONS_TRIGGER_COL) !== 'Yes') { R.skipped++; continue; }

      var name = str_(row, 4);
      if (!name) { R.skipped++; continue; }

      try {
        toast_('Creating: ' + name, 'Consultant');

        var email   = str_(row, 44);
        var annFee  = num_(row, 27), annInc = num_(row, 28), dailyFee = num_(row, 30);
        var dur     = num_(row, 5);
        var matched = pdMap.get(email.toLowerCase());
        var gender  = matched ? str_(matched, 10) : '';
        var father  = matched ? str_(matched, 3)  : '';
        var addr    = matched ? str_(matched, 4)  : '';
        var title   = gender === 'Male' ? 'Mr.' : 'Ms.';
        var sodo    = gender === 'Male' ? 'son of' : 'daughter of';
        var durStr  = dur <= 11 ? dur + ' months' : dur === 12 ? '1 year' : (dur / 12) + ' years';

        var copy = retry_(function() {
          return DriveApp.getFileById(CONFIG.TPL_CONSULTANT).makeCopy(name + ' Consultant Agreement', folder);
        });
        var body = DocumentApp.openById(copy.getId()).getBody();

        var cPairs = [
          ['##Title##',                   title],      ['##FullName##',               name],
          ['##Full Name##',               name],       ['##SoDo##',                   sodo],
          ['##FatherName##',              father],     ['##Father Name##',            father],
          ['##Address##',                 addr],       ['##Registered Address##',     addr],
          ['##ContractStartDate##',       fmtDate_(row[2])], ['##Contract Start Date##', fmtDate_(row[2])],
          ['##ContractEndDate##',         fmtDate_(row[6])], ['##Contract End Date##',   fmtDate_(row[6])],
          ['##ContractDuration##',        durStr],     ['##Contract Duration##',      durStr],
          ['##DailyFee##',                comma_(dailyFee)], ['##Daily Fee##',        comma_(dailyFee)],
          ['##DailyFeeInWords##',         inr_(dailyFee)],   ['##Daily Fee In Words##', inr_(dailyFee)],
          ['##AnnualFee##',               comma_(annFee)],   ['##Annual Fee##',       comma_(annFee)],
          ['##AnnualFeeInWords##',        inr_(annFee)],     ['##Annual Fee In Words##', inr_(annFee)],
          ['##AnnualIncentive##',         comma_(annInc)],   ['##Annual Incentive##', comma_(annInc)],
          ['##AnnualIncentiveInWords##',  inr_(annInc)],     ['##Annual Incentive In Words##', inr_(annInc)]
        ];
        replaceAll_(body, cPairs);

        DocumentApp.openById(copy.getId()).saveAndClose();
        toPdfKeep_(copy.getId(), name + ' Consultant Agreement', folder);

        consTab.getRange(i + 1, CONS_TRIGGER_COL + 1).setValue('Done');
        R.success.push({ name: name, detail: 'Fee: ' + comma_(annFee) + '/yr' });
      } catch (e) { R.errors.push({ name: name, error: e.toString().substring(0, 100) }); }
    }
    showSummary_('Consultant Agreement', R, 'agreement');
  } catch (e) { ui.alert('Error: ' + e); }
}


// ================================================================
// SECTION 11: DATA TRANSFER TO AGREEMENT SHEET
// ================================================================

function agreementDataTransfer() {
  var ui = SpreadsheetApp.getUi();
  toast_('Loading...', 'Transfer');

  var ss   = openSheet_(CONFIG.MASTER_ID);
  var pdSS = openSheet_(CONFIG.PERSONAL_ID);
  if (!ss || !pdSS) { ui.alert('Cannot open spreadsheets.'); return; }

  var srcTab = requireTab_(ss,   CONFIG.TAB_OFFERS,    'Master');
  var tgtTab = requireTab_(ss,   CONFIG.TAB_AGREEMENT, 'Master');
  var empTab = requireTab_(ss,   CONFIG.TAB_EMP,       'Master');
  var pdTab  = requireTab_(pdSS, CONFIG.TAB_PERSONAL,  'Personal Details');
  if (!srcTab || !tgtTab || !empTab || !pdTab) return;

  var srcData = srcTab.getDataRange().getValues();
  var pdData  = pdTab.getDataRange().getValues();
  var empData = empTab.getDataRange().getValues();
  var tgtData = tgtTab.getDataRange().getValues();

  toast_('Processing...', 'Transfer');

  var pdMap = new Map();
  for (var p = 1; p < pdData.length; p++) {
    var pe = String(pdData[p][12]).trim().toLowerCase();
    if (pe) pdMap.set(pe, pdData[p]);
  }

  var existing = new Set();
  for (var j = 1; j < tgtData.length; j++) {
    var te = String(tgtData[j][0]).trim().toLowerCase();
    if (te) existing.add(te);
  }

  var rows = [], moved = [], skipped = [];

  for (var k = 1; k < srcData.length; k++) {
    var row    = srcData[k];
    var status = str_(row, COL.OFFER_STATUS);
    var gen    = str_(row, COL.GENERATE);
    if (status !== 'Joined' || gen !== 'Yes') continue;

    var cEmail = row[COL.EMAIL] ? String(row[COL.EMAIL]).trim().toLowerCase() : '';
    var cName  = str_(row, COL.NAME);
    if (existing.has(cEmail)) { skipped.push(cName); continue; }

    var hrbp = str_(row, COL.HRBP), capt = str_(row, COL.HIRING_CAPTAIN), cxo = str_(row, COL.CXO);
    var pd   = pdMap.get(cEmail);
    var r    = new Array(57).fill('');

    r[0] = cEmail;       r[1] = cName;            r[2] = row[COL.JOINING_DATE] || '';
    r[3] = str_(row, COL.REQ_CODE);
    r[4] = CONFIG.COMPANY_NAME;
    r[5] = 'FTE';
    r[6] = str_(row, COL.PRODUCT_BU);
    r[15] = str_(row, COL.LEVEL);    r[16] = str_(row, COL.DESIGNATION);
    r[19] = lookupEmpCode_(hrbp, empData); r[20] = hrbp;
    r[21] = lookupEmpCode_(capt, empData); r[22] = capt;
    r[23] = lookupEmpCode_(cxo,  empData); r[24] = cxo;
    r[25] = num_(row, COL.OFFERED_CTC); r[26] = num_(row, COL.JOINING_BONUS);
    r[28] = num_(row, COL.ESOP_VALUE);

    if (pd) {
      for (var m = 1; m <= 28; m++) r[28 + m] = pd[m] || '';
    }

    rows.push(r); moved.push(cName); existing.add(cEmail);
  }

  if (rows.length) tgtTab.getRange(tgtTab.getLastRow() + 1, 1, rows.length, 57).setValues(rows);

  var R = { success: moved.map(function(n) { return { name: n, detail: 'Transferred' }; }), errors: [], skipped: skipped.length };
  showSummary_('Data Transfer', R, 'transfer');
}


// ================================================================
// SECTION 12: PUSH TO ONBOARDING SHEET
// ================================================================

function pushToOnboardingSheet() {
  var ui = SpreadsheetApp.getUi();
  toast_('Loading...', 'Onboarding Push');

  var ss    = openSheet_(CONFIG.MASTER_ID);
  var tgtSS = openSheet_(CONFIG.ONBOARDING_ID);
  if (!ss || !tgtSS) { ui.alert('Cannot open spreadsheets.'); return; }

  var srcTab = requireTab_(ss,    CONFIG.TAB_AGREEMENT,  'Master');
  var tgtTab = requireTab_(tgtSS, CONFIG.TAB_ONBOARDING, 'Onboarding Sheet');
  if (!srcTab || !tgtTab) return;

  var srcData = srcTab.getDataRange().getValues();
  var tgtData = tgtTab.getDataRange().getValues();
  if (srcData.length < 2) { ui.alert('No data rows.'); return; }

  var srcH = srcData[0].map(function(h) { return String(h).trim(); });

  // Headers start at row 3 (index 2); data from row 5 (index 4)
  var HEADER_ROW = 2;
  if (tgtData.length <= HEADER_ROW) { ui.alert('Target sheet must have headers on row 3.'); return; }
  var tgtH = tgtData[HEADER_ROW].map(function(h) { return String(h).trim(); });

  // Build column map by matching header names
  var hMap = [], matched = 0;
  tgtH.forEach(function(th) {
    var idx = -1;
    if (th) {
      var tl = th.toLowerCase();
      srcH.forEach(function(sh, si) { if (idx < 0 && sh.toLowerCase() === tl) idx = si; });
      if (idx >= 0) matched++;
    }
    hMap.push(idx);
  });

  toast_(matched + ' headers matched', 'Mapping');

  var exists = new Set();
  for (var j = HEADER_ROW + 1; j < tgtData.length; j++) {
    var e = String(tgtData[j][0]).trim().toLowerCase();
    if (e) exists.add(e);
  }

  var rows = [], names = [], skip = 0;
  for (var k = 1; k < srcData.length; k++) {
    var sr = srcData[k];
    var se = String(sr[0]).trim().toLowerCase();
    var sn = String(sr[1]).trim();
    if (!se && !sn) continue;
    if (exists.has(se)) { skip++; continue; }
    rows.push(hMap.map(function(idx) { return idx >= 0 ? sr[idx] : ''; }));
    names.push(sn || se); exists.add(se);
  }

  if (rows.length) tgtTab.getRange(tgtTab.getLastRow() + 1, 1, rows.length, tgtH.length).setValues(rows);

  var R = { success: names.map(function(n) { return { name: n, detail: 'Pushed' }; }), errors: [], skipped: skip };
  showSummary_('Onboarding Push', R, 'push');
}


// ================================================================
// SECTION 13: SHARED UTILITIES
// ================================================================

function salaryBreakup_(ctc, withPF) {
  var S  = CONFIG.SALARY;
  var yb = Math.max(Math.round(ctc * S.BASIC_PCT), S.BASIC_MIN);
  var yh = Math.round(ctc * S.HRA_PCT);
  var ded = yb + yh + S.LTA_ANNUAL + S.FOOD_ANNUAL + (withPF ? S.PF_ANNUAL : 0);
  var ye = ctc - ded;
  return {
    Yb: yb,            Mb: Math.round(yb / 12),
    Yh: yh,            Mh: Math.round(yh / 12),
    Ye: ye,            Me: Math.round(ye / 12),
    Mc: Math.round(ctc / 12)
  };
}

function toPdf_(docId, name, folder) {
  retry_(function() {
    var f = DriveApp.getFileById(docId);
    folder.createFile(f.getAs('application/pdf')).setName(name);
    f.setTrashed(true);
  });
}

function toPdfKeep_(docId, name, folder) {
  retry_(function() {
    var f = DriveApp.getFileById(docId);
    // Add to target first, then remove from source (prevents orphaned files on error)
    folder.addFile(f);
    folder.createFile(f.getAs('application/pdf')).setName(name);
    f.setName(name);
    var parents = f.getParents();
    while (parents.hasNext()) {
      var p = parents.next();
      if (p.getId() !== folder.getId()) p.removeFile(f);
    }
  });
}

function comma_(n)    { return Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 }); }
function fmtLPA_(n)   { return (!n || n === 0) ? '0' : parseFloat((n / 100000).toFixed(2)).toString(); }
function pf2_(n)      { return parseFloat(n.toFixed(2)).toString(); }

function fmtDate_(d) {
  var dt = new Date(d);
  if (isNaN(dt)) return '';
  var day = dt.getDate();
  var m   = dt.toLocaleString('default', { month: 'long' });
  var y   = dt.getFullYear();
  var suf = (day > 3 && day < 21) ? 'th' : ['th','st','nd','rd','th'][Math.min(day % 10, 4)];
  return day + suf + ' of ' + m + ', ' + y;
}

function parseHikeOrPercent_(raw) {
  if (!raw || raw === '#NUM!' || raw === 'NA') return 'N/A';
  var n = parseFloat(raw.replace('%', '').trim());
  if (isNaN(n)) return 'NA';
  // Values < 1 are decimal (e.g. 0.24 = 24%) — multiply up
  if (Math.abs(n) < 1) n = n * 100;
  return pf2_(n);
}

function sendOfferEmail_(to, name, desg, ctcStr) {
  try {
    var html = '<div style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:560px;margin:0 auto;color:#1C1C1E">'
      + '<div style="background:#007AFF;padding:28px 32px;border-radius:16px 16px 0 0">'
      + '<h2 style="color:#fff;margin:0;font-size:20px;font-weight:600">Welcome to ' + CONFIG.COMPANY_NAME + '</h2>'
      + '<p style="color:rgba(255,255,255,0.8);margin:6px 0 0;font-size:13px">We are thrilled to have you join us</p></div>'
      + '<div style="padding:28px 32px;background:#F9F9F9;border:1px solid #E5E5EA;border-top:none;border-radius:0 0 16px 16px">'
      + '<p>Dear <strong>' + name + '</strong>,</p>'
      + '<p>Congratulations! We are pleased to offer you the position of <strong>' + desg + '</strong>.</p>'
      + '<div style="background:#fff;border:1px solid #E5E5EA;border-radius:12px;padding:16px 20px;margin:20px 0">'
      + '<p style="margin:4px 0"><strong>Position:</strong> ' + desg + '</p>'
      + '<p style="margin:4px 0"><strong>Fixed CTC:</strong> INR ' + ctcStr + ' per annum</p></div>'
      + '<p style="font-size:13px;color:#8E8E93">Please review the attached offer letter and respond within 24 hours.</p>'
      + '<p style="margin:0;color:#8E8E93;font-size:12px;margin-top:24px">Best regards,<br><strong>' + CONFIG.HR_NAME + '</strong></p>'
      + '</div></div>';
    GmailApp.sendEmail(to, 'Offer Letter - ' + name + ' | ' + CONFIG.COMPANY_NAME, '', {
      htmlBody: html, name: CONFIG.HR_NAME, replyTo: CONFIG.HR_EMAIL
    });
  } catch (e) { _log('Email fail: ' + e); }
}

function inr_(n) {
  if (n === 0) return 'INR Zero Only';
  var int   = Math.floor(n), paise = Math.round((n - int) * 100);
  var out   = 'INR ' + words_(int);
  if (paise > 0) out += ' and ' + words_(paise) + ' Paise';
  return out + ' Only';
}

function words_(n) {
  var O = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine'];
  var T = ['Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
  var D = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];

  function h(x) {
    if (x > 0 && x < 10)  return O[x];
    if (x > 9 && x < 20)  return T[x % 10];
    if (x > 19 && x < 100){ var r = D[Math.floor(x/10)]; if (x%10) r += ' ' + O[x%10]; return r; }
    return '';
  }

  var parts = [];
  var cr = Math.floor(n / 10000000);       // supports up to 999 crore
  var lk = Math.floor(n / 100000) % 100;
  var th = Math.floor(n / 1000) % 100;
  var hu = Math.floor(n % 1000 / 100);
  var re = n % 100;

  if (cr) parts.push(h(cr) + ' Crore');
  if (lk) parts.push(h(lk) + ' Lakh');
  if (th) parts.push(h(th) + ' Thousand');
  if (hu) parts.push(O[hu] + ' Hundred');
  if (n > 100 && re) parts.push('and');
  if (re) parts.push(h(re));

  return parts.join(' ').trim();
}


// ================================================================
// SECTION 14: PLACEHOLDER FUNCTIONS (not yet implemented)
// ================================================================

function updatehikeandstocks()        { SpreadsheetApp.getUi().alert('Coming soon: Auto field update.'); }
function downalertpop()               { SpreadsheetApp.getUi().alert('Coming soon: Post-offer workflow.'); }
function runOnboardingUpdates()       { SpreadsheetApp.getUi().alert('Coming soon: Onboarding updates.'); }
function updateautofieldsconsultants(){ SpreadsheetApp.getUi().alert('Coming soon: Consultant auto fields.'); }
function consultantoffer()            { SpreadsheetApp.getUi().alert('Coming soon: Consultant offer creation.'); }
function poeInitiatorConsultants()    { SpreadsheetApp.getUi().alert('Coming soon: Consultant post-offer.'); }
function runOnboardingUpdatesCons()   { SpreadsheetApp.getUi().alert('Coming soon: Consultant onboarding.'); }
function ctccalculator()              { SpreadsheetApp.getUi().alert('Coming soon: CTC calculator.'); }
